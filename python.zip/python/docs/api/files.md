# files

::: acl_anthology.files
    options:
      members:
        - FileReference

::: acl_anthology.files
    options:
      filters:
        - "!^FileReference$"
