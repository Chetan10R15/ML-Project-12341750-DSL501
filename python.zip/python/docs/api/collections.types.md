# collections.types

::: acl_anthology.collections.types
