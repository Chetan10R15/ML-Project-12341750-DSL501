# text

::: acl_anthology.text.markuptext

::: acl_anthology.text.stopwords

::: acl_anthology.text.texmath
