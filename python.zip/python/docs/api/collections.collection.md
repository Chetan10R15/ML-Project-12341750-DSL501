# collections.collection

::: acl_anthology.collections.collection
