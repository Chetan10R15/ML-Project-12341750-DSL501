# utils.attrs

!!! danger

    You probably don't want to touch these functions unless you are modifying the library itself.


::: acl_anthology.utils.attrs
