# people.person

::: acl_anthology.people.person
